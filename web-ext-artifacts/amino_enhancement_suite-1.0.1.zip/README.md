# Amino-Enhancement-Suite
An Enhancement suite for the AminoApps website

##Click aqui para la version en Español

Amino Enhancement Suite is a set of tools to improve your experience while using the AminoApps website (aminoapps.com). It includes the following features:

- Hide the amino Banner
- Hide annoying community list blur
- Hide animated chat
- Re-arrange some web-elements for a better experience
- Choose what to hide and what not to hide
