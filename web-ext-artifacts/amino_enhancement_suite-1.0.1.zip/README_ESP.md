# Amino-Enhancement-Suite
Una suite de mejoras para la pagina de AminoApps

##Click here for the English version

La Suite de Mejoras de Amino es un set de herramientas que sirven para mejorar tu experiencia mientras utilizas la pagina de AminoApps (aminoapps.com). Incluye los siguientes capacidades:

- Ocultar el banner de amino
- Ocultar la molesta neblina de la lista de comunidades
- Ocultar el chat animado
- Re-acomodar algunos elementos web para una mejor experiencia
- Configurar que cosas ocultar y que no